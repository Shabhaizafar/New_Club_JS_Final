"use strict";
// What is a Variable : 
// var num1 = 12;
// var num1 = 'Hello';
// var num1 = "Hello";
// var num1 = `12345`;
// var num1 = false;

//object
// var num1 = [1,2,3,45,6];
// var num1 = {
//     fname : "Zafar"
// }

// var num1= null;
// var num1;
// console.log(num1);

// console.log(typeof num1);
// console.log(typeof(num1));

// Valid
// var _num1 = 12;
// var $num1 = 12;
// console.log($num1);


//number,string,boolean,object(object,array,null),undefined

/////////////////////////////////

// num1 = "Royal";
// console.log(num1);

// console.log(typeof num1);

//define a Variable : 
//var,let,const
//////////////////////////////////////////////////////////////
// 1) var 

// - 
var num1 = 100;
console.log(num1);
// num1 = 1001;
// console.log(num1);
var num1 = 300;
console.log(num1);

// 2) let
let num2 = 200;
console.log(num2);
// num2 = 2002;
// console.log(num2);
// let num2 = 1;

// 3) const
const num3 = 400;
console.log(num3);
// num3 = 4004;
// console.log(num3);//error
// const num3 = 1;
