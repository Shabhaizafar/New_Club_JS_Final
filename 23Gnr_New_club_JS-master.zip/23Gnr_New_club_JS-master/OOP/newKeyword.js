// new keyword : 

// 1) creates a new empty object
// 2) this keyword
// 3) return this   this = object




function User(fname){
    this.fname= fname;
    return this;
}

var p1 = new User("Arin");
console.log(p1);