// document.write("<h1>Hello</h1>");
// document.write("<i>Everyone</i><br>");
// document.write("<br>Bye");

// document.write("<style>h1{color:red;}</style>");


