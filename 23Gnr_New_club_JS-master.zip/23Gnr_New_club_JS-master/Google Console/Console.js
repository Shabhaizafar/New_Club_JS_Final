// document.write("Hello")


// // 

// // console.log("Hello Everyone")

// console.time("Time");
// console.error("This a Error");

// console.warn("This a Warning");

// console.log([1,2,3,4,5,6]);
// console.table([1,2,3,4,5,6]);
// console.timeEnd("Time is :");

// =