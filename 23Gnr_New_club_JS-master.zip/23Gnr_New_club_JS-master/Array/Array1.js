// Array in JS: 
// - refferemce Datatype
// - collaction of Multiplle Data with different Datatype


// var n1 = 12;
// var n2 = n1;

// console.log("Value of  n1: ",n1);//12
// console.log("Value of  n1: ",n2);//12
// n1++;
// console.log("After incrementing n1 by one, the value is :",n1);
// console.log("After incrementing n1 by one, the value is :",n2);

// var Arr1 = [1,2,3,"Zafar",true,null,undefined];
// var Arr2 = Arr1;

// console.log("Array 1 is : ",Arr1);
// console.log("Array 2 is : ",Arr2);
// Arr1.push(100);
// Arr2.push(101);
// console.log("After adding an element to array 1 , the new array 1 is : ",Arr1);
// console.log("After adding an element to array 1 , the new array 2 is : ",Arr2);

// var Arr = [1];
// console.log("The original array is : ",Arr);
// console.log(typeof Arr);

// Arr1 = [1,2,3];
//Address ?

var Arr = [1,2,3];
var Arr2 = [1,2,3];
console.log("Original Array is : ",Arr);
console.log("Typeof Array is : ", typeof Arr);

Arr.push(12);
console.log("Modified Array after pushing a number into it : ",Arr);
console.log("Modified Array after pushing a number into it : ",Arr2);