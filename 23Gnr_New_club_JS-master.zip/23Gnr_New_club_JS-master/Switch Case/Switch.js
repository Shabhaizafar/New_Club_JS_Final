// var n1 = 12;
// var n2 = 13;

// console.log("1) Addition");
// console.log("2) Subtraction");
// console.log("3) Multiplication");
// var Userchoice = "#";
// switch(Userchoice)
// {
//     case '+' : console.log("Addition  : ",n1+n2);
//              break;
//     case "subtraction" : console.log("Sub  : ",n1-n2);
//              break;
//     case '#' : console.log("Mul  : ",n1*n2);
//              break;
//     default : console.log("Please Enter Valid Choice !!!");       
// }