/*
Syntax : 

 var n1 = 10;
 for(initialization;condition;inc/dec){
        block Code(statement);
 }
 */
// var n1 = 10;
// for (let i = 0; i <=n1; i++) {
//     console.log("I love to code",i);
// }

