// 100<

/*
Syntax : 
initialization;
while(condition)
{
    code block to be executed repeatedly;
    inc/dec;
}
*/ 


// var  x = 5;
// let i = 1;
// while(i<x)
// {
//     console.log(i);
//     i++;
// }

// my Name is Zafar.I Love Coding.
// a " "
// o 

//  12,1,24,5,78,0-,76,54,12


// 5
