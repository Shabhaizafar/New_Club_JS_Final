/*
Syntax : 
intialization;
do{
    //code to be executed repeatedly;
    inc/dec;
}while(condition);
*/ 


// var x = 10;
// let i = 11;
// do{
//     console.log("Value of I is: " + i);
//     i++;
// }while(i<=x);

// console.log(1);