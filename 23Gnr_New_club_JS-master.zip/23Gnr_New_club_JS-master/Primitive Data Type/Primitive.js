// Primitive Data Type : 
// 1) number 
// var num1 = 12;
// console.log(num1);
// console.log(typeof num1);//number

// var n2 = 3.14;
// console.log(n2);
// console.log(typeof n2);

// console.log(num1+n2); // 15.14

// var num = 1234567890123456;
// console.log(num);

//BigInt
// var num = 12345678901234567890n;
// console.log(num);
// console.log(typeof num);

// console.log(num+num1);//error
// console.log(num+ BigInt(num1));

// var n2 = 12n;
// var n1 = 12;
// console.log(n2+ n1);
// console.log(typeof n2);

//////////////////////////////////////////
// 2) String : 
var s1 = "raj";
// var s2 = 'arin';
// var s3 = `Royal`;
// console.log(s1,s2,s3);

// console.log(s1+s2+s3);

// var s4 = "1+1";
// var s1 = '2.2';
// var s1 = 0;
// var s4 = '2n';
// var s4 = "true";
// console.log(+s1+(+s4));//3

// console.log(s1-s4);


// console.log(Number(s4));


//////////////////////////////////////////
// 3) Boolean : 


// var F1 = true;
// var F1 = false;
// console.log(F1);
// console.log(typeof F1);//boolean



// var f1 = "";
// console.log(Boolean(f1));

// Truly Values : 
// true,1,1.1,1123456,"Zafar",[a,d,g],{fname:"asd"},-3.13

// Falsy Values : 
// "",0,false,null,undefined,NaN,""


// var f1 = true;

// console.log(Number(f1));
//0 or 1

// var f1 = false;
// console.log(BigInt(f1));
// var f1  = -0;
// console.log(Boolean(f1));
////////////////////////////////////
/*
Practice Quiz Questions of Primitive Data type : 
Q1: What will be the output of the following code?
console.log("Hello " + undefined + " World");

Q1) What will be the output of the following code?
console.log("Hello " + "World");
Q1) What is the output of (true + "Hello")?
Q: What will be the output of following code?
console.log("Hello " + undefined);

*/




