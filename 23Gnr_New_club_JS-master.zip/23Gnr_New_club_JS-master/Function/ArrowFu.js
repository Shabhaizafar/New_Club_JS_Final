
//Arrow Function : 

// 1) without argument and without return type
// var Hello = ()=>console.log("Hello Everyone !!!!");
// Hello();




// 2) with argument and without return type
// var Add = n1=>console.log(n1);
// Add(12);//12,13, Argument


// var Add = n1=>{//perameter
//     console.log(n1);
// }
// Add(12);//12,13, Argument

// var Add = (n1,n2)=>{//perameter
//     console.log(n1+n2);
// }
// Add(12,13);//12,13, Argument



// 3) without argument and with return type
// var Multiply = ()=>{return 2;}//return type
// var ans =  Multiply();
// console.log(ans);





// 4) with argument and with return type

// var Sum =  (n1,n2)=>{ //n1,n2 Perameter
//     return n1+n2;//return type
// }
// var output = Sum(1,2);//1,2 argument
// console.log(output);




// function Expression  
// 2. Write a JavaScript function that checks whether a passed string is a palindrome or not?
// A palindrome is word, phrase, or sequence that reads the same backward as forward, e.g., madam or nurses run. 



// Function Arrow
// 3. Write a JavaScript function that generates all combinations of a string.
// Example string : 'dog'
// Expected Output : d,do,dog,o,og,g 


// IIFE 
// 4. Write a JavaScript function that returns a string that has letters in alphabetical order.
// Example string : 'webmaster'
// Expected Output : 'abeemrstw'
// Assume punctuation and numbers symbols are not included in the passed string.