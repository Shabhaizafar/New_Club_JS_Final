#include<stdio.h>
void main()
{
   // printf("Hello");
   Hello();
}

void Hello(){
    printf("Hello");
}