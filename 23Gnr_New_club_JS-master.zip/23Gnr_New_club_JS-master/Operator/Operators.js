// Operators : 
// 1. Arithmetic operators (+, -, *, /,%,++,--)

// var n1 = 12;
// var n2 = 13;
// console.log("Addition :",n1+n2);
// // console.log("Addition :"+(n1+n2));
// console.log("Subtraction : ",n1-n2);
// console.log("Multiplication : ",n1*n2);
// console.log("Division : ",n1/n2);
// console.log("Moduler : ",n1%n2);
// console.log("n1 : ",n1++);
// console.log("Post Increment : ",n1);
// console.log("n2 : ",n2--);
// console.log("Deccrement : ",n2);


// var n1 = "Royal";
// var n2 = "Techno";

// console.log(n1+n2); // Concate
// console.log(n1-n2); // NaN

// var n1 = "1";
// var n2 = "2";
// console.log(n1+n2); // Concate
// console.log(n1-n2); // -1

// var n1= "1";
// var n2 = 2;

// console.log(n1+n2); // Concate
// console.log(n1-n2); // -1

// var n1 = true; //1
// var n2 = false;//0
// console.log(n2+n1); // 1
// console.log(n2-n1); // 1

// var n1 = undefined;
// var n2 = undefined;

// console.log(typeof(n2),typeof(n1)); // 

// console.log(n2+n1); // 1


// #####################################
// 2. Comparison operators (==, !=, >, <, >=, <= , ===,!==)

var n1 = "1";//String    // value
var n2 = 1;//Number      //value

console.log(n1==n2); //true     // check only Values
 
console.log(n1===n2); //        // check Both (Types  and Value)


console.log(n1!=n2);// false
console.log(n1!==n2);// true


//////////////////////////////////
// 3. Logical Operators  (&& ,||, !)

// &&   : all condition True return always true else False
// var s1 = "Hello";
// var s2 = "World";
// var s3 = "M"
// console.log((s1==s2) && () &&());

// ||   : all condition False return always False else True  


// !  = true > false    false > true
////////////////////////////////////////
// 4. Assignment  Operators
// +=,-=,.....,=
// var n1 = 12;
// var n2 ; //1

// var n3 = n1+n2;
// console.log(n3);// 13

// var n1  = 13;
// var n2 = n1++;// n1=n1+1

// var n3 = n1+n2;
// console.log(n3);//26//27
///////////