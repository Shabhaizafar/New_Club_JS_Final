// What is a String in a JS :
// A string is a sequence of characters. It can be created using either single quotes or double quotes or backtick.
//          12345
// var str1 = "Zafar shabhaiasdfghjkloiuytfds";
// //          01234
// console.log(str1);
// var str2 = 'Royal';
// console.log(str2);
// var str3 = `Techno`;
// console.log(str3);

// console.log(typeof str1,typeof str2,typeof str3);


// console.log(str1.length);
// console.log(str1[str1.length-1]);
